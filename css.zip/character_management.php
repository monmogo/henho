<div class="col-md-2 col-sm-1 hidden-xs display-table-cell v-align box" id="navigation">
                <?php include 'navigation.php'; ?>
            </div>